<?php

/* form/fields.html.twig */
class __TwigTemplate_7bf546d4b11af81c305b759456ded7bee82922e1531c3331428ec96748119502 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
            'date_time_picker_widget' => array($this, 'block_date_time_picker_widget'),
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_84ff79f6bda84e893846cf4d59a476aa0ba1254ce796e946ac709ba564b1ea3b = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_84ff79f6bda84e893846cf4d59a476aa0ba1254ce796e946ac709ba564b1ea3b->enter($__internal_84ff79f6bda84e893846cf4d59a476aa0ba1254ce796e946ac709ba564b1ea3b_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "form/fields.html.twig"));

        // line 9
        echo "
";
        // line 10
        $this->displayBlock('date_time_picker_widget', $context, $blocks);
        
        $__internal_84ff79f6bda84e893846cf4d59a476aa0ba1254ce796e946ac709ba564b1ea3b->leave($__internal_84ff79f6bda84e893846cf4d59a476aa0ba1254ce796e946ac709ba564b1ea3b_prof);

    }

    public function block_date_time_picker_widget($context, array $blocks = array())
    {
        $__internal_ff628383c2c7ee455c74058f1c57dbc2112d4775a1da2a77116a0be9b3698a8e = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_ff628383c2c7ee455c74058f1c57dbc2112d4775a1da2a77116a0be9b3698a8e->enter($__internal_ff628383c2c7ee455c74058f1c57dbc2112d4775a1da2a77116a0be9b3698a8e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "date_time_picker_widget"));

        // line 11
        echo "    ";
        ob_start();
        // line 12
        echo "        <div class=\"input-group date\" data-toggle=\"datetimepicker\">
            ";
        // line 13
        $this->displayBlock("datetime_widget", $context, $blocks);
        echo "
            ";
        // line 15
        echo "                ";
        // line 16
        echo "            ";
        // line 17
        echo "        </div>
    ";
        echo trim(preg_replace('/>\s+</', '><', ob_get_clean()));
        
        $__internal_ff628383c2c7ee455c74058f1c57dbc2112d4775a1da2a77116a0be9b3698a8e->leave($__internal_ff628383c2c7ee455c74058f1c57dbc2112d4775a1da2a77116a0be9b3698a8e_prof);

    }

    public function getTemplateName()
    {
        return "form/fields.html.twig";
    }

    public function getDebugInfo()
    {
        return array (  52 => 17,  50 => 16,  48 => 15,  44 => 13,  41 => 12,  38 => 11,  26 => 10,  23 => 9,);
    }

    public function getSource()
    {
        return "{#
   Each field type is rendered by a template fragment, which is determined
   by the name of your form type class (DateTimePickerType -> date_time_picker)
   and the suffix \"_widget\". This can be controlled by overriding getBlockPrefix()
   in DateTimePickerType.

   See http://symfony.com/doc/current/cookbook/form/create_custom_field_type.html#creating-a-template-for-the-field
#}

{% block date_time_picker_widget %}
    {% spaceless %}
        <div class=\"input-group date\" data-toggle=\"datetimepicker\">
            {{ block('datetime_widget') }}
            {#<span class=\"input-group-addon\">#}
                {#<span class=\"fa fa-calendar\" aria-hidden=\"true\"></span>#}
            {#</span>#}
        </div>
    {% endspaceless %}
{% endblock %}
";
    }
}
